import urllib,urllib2,re, string
import xbmc, xbmcgui, xbmcaddon, xbmcplugin
import urlresolver

#WatchFreeSeries - by Mash2k3 2012.

Mainurl ='http://watch-freeseries.mu/'
addon_id = 'plugin.video.watchfreeseries'
selfAddon = xbmcaddon.Addon(id=addon_id)
def MAIN():
        addDir('Search','http://watch-freeseries.mu/',4,"%s/art/search.png"%selfAddon.getAddonInfo("path"))
        addDir('A-Z','http://watch-freeseries.mu/tvseries',10,"%s/art/az.png"%selfAddon.getAddonInfo("path"))
        addDir('This Week Episodes','http://watch-freeseries.mu/this-week-episodes/',1,"%s/art/latest.png"%selfAddon.getAddonInfo("path"))
        addDir('Popular TV Series','http://watch-freeseries.mu/',11,"%s/art/popu.png"%selfAddon.getAddonInfo("path"))
        addDir('TV Series','http://watch-freeseries.mu/tvseries',6,"%s/art/series.png"%selfAddon.getAddonInfo("path"))
        addDir('Year','http://watch-freeseries.mu/',5,"%s/art/year.png"%selfAddon.getAddonInfo("path"))
        addDir('Genre','http://watch-freeseries.mu/',2,"%s/art/genre.png"%selfAddon.getAddonInfo("path"))
        VIEWSB()

def AtoZ():
        addDir('0-9','http://watch-freeseries.mu/index.php?action=episodes_searchShow&letter=1',6,"%s/art/09.png"%selfAddon.getAddonInfo("path"))
        for i in string.ascii_uppercase:
                addDir(i,'http://watch-freeseries.mu/index.php?action=episodes_searchShow&letter='+i,6,"%s/art/%s.png"%(selfAddon.getAddonInfo("path"),i))
                
def GENRE(url):
        addDir('Action','http://watch-freeseries.mu/index.php?action=episodes_searchShow&genre=2',6,"%s/art/act.png"%selfAddon.getAddonInfo("path"))
        addDir('Adventure','http://watch-freeseries.mu/index.php?action=episodes_searchShow&genre=5',6,"%s/art/adv.png"%selfAddon.getAddonInfo("path"))
        addDir('Animation','http://watch-freeseries.mu/index.php?action=episodes_searchShow&genre=6',6,"%s/art/ani.png"%selfAddon.getAddonInfo("path"))
        addDir('Awards','http://watch-freeseries.mu/index.php?action=episodes_searchShow&genre=32',6,"%s/art/awa.png"%selfAddon.getAddonInfo("path"))
        addDir('Biography','http://watch-freeseries.mu/index.php?action=episodes_searchShow&genre=8',6,"%s/art/bio.png"%selfAddon.getAddonInfo("path"))
        addDir('Cartoons','http://watch-freeseries.mu/index.php?action=episodes_searchShow&genre=30',6,"%s/art/car.png"%selfAddon.getAddonInfo("path"))
        addDir('Comedy','http://watch-freeseries.mu/index.php?action=episodes_searchShow&genre=9',6,"%s/art/com.png"%selfAddon.getAddonInfo("path"))
        addDir('Cooking','http://watch-freeseries.mu/index.php?action=episodes_searchShow&genre=39',6,"%s/art/coo.png"%selfAddon.getAddonInfo("path"))
        addDir('Crime','http://watch-freeseries.mu/index.php?action=episodes_searchShow&genre=10',6,"%s/art/cri.png"%selfAddon.getAddonInfo("path"))
        addDir('Documentary','http://watch-freeseries.mu/index.php?action=episodes_searchShow&genre=11',6,"%s/art/doc.png"%selfAddon.getAddonInfo("path"))
        addDir('Drama','http://watch-freeseries.mu/index.php?action=episodes_searchShow&genre=3',6,"%s/art/dra.png"%selfAddon.getAddonInfo("path"))
        addDir('Family','http://watch-freeseries.mu/index.php?action=episodes_searchShow&genre=12',6,"%s/art/fam.png"%selfAddon.getAddonInfo("path"))
        addDir('Fantasy','http://watch-freeseries.mu/index.php?action=episodes_searchShow&genre=1',6,"%s/art/fan.png"%selfAddon.getAddonInfo("path"))
        addDir('Fashion','http://watch-freeseries.mu/index.php?action=episodes_searchShow&genre=35',6,"%s/art/fas.png"%selfAddon.getAddonInfo("path"))
        addDir('Food','http://watch-freeseries.mu/index.php?action=episodes_searchShow&genre=31',6,"%s/art/foo.png"%selfAddon.getAddonInfo("path"))
        addDir('Game Show','http://watch-freeseries.mu/index.php?action=episodes_searchShow&genre=33',6,"%s/art/gam.png"%selfAddon.getAddonInfo("path"))
        addDir('History','http://watch-freeseries.mu/index.php?action=episodes_searchShow&genre=14',6,"%s/art/his.png"%selfAddon.getAddonInfo("path"))
        addDir('Horror','http://watch-freeseries.mu/index.php?action=episodes_searchShow&genre=4',6,"%s/art/hor.png"%selfAddon.getAddonInfo("path"))
        addDir('Late Night','http://watch-freeseries.mu/index.php?action=episodes_searchShow&genre=37',6,"%s/art/lat.png"%selfAddon.getAddonInfo("path"))
        addDir('Motorsports','http://watch-freeseries.mu/index.php?action=episodes_searchShow&genre=29',6,"%s/art/mot.png"%selfAddon.getAddonInfo("path"))
        addDir('Music','http://watch-freeseries.mu/index.php?action=episodes_searchShow&genre=17',6,"%s/art/mus.png"%selfAddon.getAddonInfo("path"))
        addDir('Musical','http://watch-freeseries.mu/index.php?action=episodes_searchShow&genre=18',6,"%s/art/musi.png"%selfAddon.getAddonInfo("path"))
        addDir('Mystery','http://watch-freeseries.mu/index.php?action=episodes_searchShow&genre=16',6,"%s/art/mys.png"%selfAddon.getAddonInfo("path"))
        addDir('Reality Tv','http://watch-freeseries.mu/index.php?action=episodes_searchShow&genre=19',6,"%s/art/rea.png"%selfAddon.getAddonInfo("path"))
        addDir('Romance','http://watch-freeseries.mu/index.php?action=episodes_searchShow&genre=20',6,"%s/art/rom.png"%selfAddon.getAddonInfo("path"))
        addDir('Sci-Fi','http://watch-freeseries.mu/index.php?action=episodes_searchShow&genre=21',6,"%s/art/sci.png"%selfAddon.getAddonInfo("path"))
        addDir('Short','http://watch-freeseries.mu/index.php?action=episodes_searchShow&genre=22',6,"%s/art/sho.png"%selfAddon.getAddonInfo("path"))
        addDir('Sport','http://watch-freeseries.mu/index.php?action=episodes_searchShow&genre=23',6,"%s/art/spo.png"%selfAddon.getAddonInfo("path"))
        addDir('Talk','http://watch-freeseries.mu/index.php?action=episodes_searchShow&genre=27',6,"%s/art/tal.png"%selfAddon.getAddonInfo("path"))
        addDir('Talk Show','http://watch-freeseries.mu/index.php?action=episodes_searchShow&genre=8',6,"%s/art/tals.png"%selfAddon.getAddonInfo("path"))
        addDir('Teen','http://watch-freeseries.mu/index.php?action=episodes_searchShow&genre=34',6,"%s/art/tee.png"%selfAddon.getAddonInfo("path"))
        addDir('Thriller','http://watch-freeseries.mu/index.php?action=episodes_searchShow&genre=24',6,"%s/art/thr.png"%selfAddon.getAddonInfo("path"))
        addDir('War','http://watch-freeseries.mu/index.php?action=episodes_searchShow&genre=25',6,"%s/art/war.png"%selfAddon.getAddonInfo("path"))
        addDir('Western','http://watch-freeseries.mu/index.php?action=episodes_searchShow&genre=26',6,"%s/art/wes.png"%selfAddon.getAddonInfo("path"))

def YEAR():
        addDir('2013','http://watch-freeseries.mu/index.php?action=episodes_searchShow&year=2013',6,"%s/art/2013.png"%selfAddon.getAddonInfo("path"))
        addDir('2012','http://watch-freeseries.mu/index.php?action=episodes_searchShow&year=2012',6,"%s/art/2012.png"%selfAddon.getAddonInfo("path"))
        addDir('2011','http://watch-freeseries.mu/index.php?action=episodes_searchShow&year=2011',6,"%s/art/2011.png"%selfAddon.getAddonInfo("path"))
        addDir('2010','http://watch-freeseries.mu/index.php?action=episodes_searchShow&year=2010',6,"%s/art/2010.png"%selfAddon.getAddonInfo("path"))
        addDir('2009','http://watch-freeseries.mu/index.php?action=episodes_searchShow&year=2009',6,"%s/art/2009.png"%selfAddon.getAddonInfo("path"))
        addDir('2008','http://watch-freeseries.mu/index.php?action=episodes_searchShow&year=2008',6,"%s/art/2008.png"%selfAddon.getAddonInfo("path"))
        addDir('2007','http://watch-freeseries.mu/index.php?action=episodes_searchShow&year=2007',6,"%s/art/2007.png"%selfAddon.getAddonInfo("path"))
        addDir('2006','http://watch-freeseries.mu/index.php?action=episodes_searchShow&year=2006',6,"%s/art/2006.png"%selfAddon.getAddonInfo("path"))
        addDir('2005','http://watch-freeseries.mu/index.php?action=episodes_searchShow&year=2005',6,"%s/art/2005.png"%selfAddon.getAddonInfo("path"))
        addDir('2004','http://watch-freeseries.mu/index.php?action=episodes_searchShow&year=2004',6,"%s/art/2004.png"%selfAddon.getAddonInfo("path"))
        addDir('2003','http://watch-freeseries.mu/index.php?action=episodes_searchShow&year=2003',6,"%s/art/2003.png"%selfAddon.getAddonInfo("path"))
 
        
def LISTEpi(murl):
        link=OPENURL(murl)
        match=re.compile('<a href="(.+?)">\n                                                                        <img src="(.+?)"/>\n                                                                    </a>\n                            </div>\n                            <div class="right-fav">\n                                <a class="title" href=".+?">(.+?)</a>\n                                <p class="description">(.+?)</p>\n').findall(link)
        for url,thumb,name,desc in match:
                addInfo(name,url,thumb,3,desc,'','','','','')
        xbmcplugin.setContent(int(sys.argv[1]), 'Movies')
        VIEWS()
        
def LISTShows(murl):
        link=OPENURL(murl)
        match=re.compile('<div class=".+?">\n                    <a href="(.+?)">\n                        <span class=".+?">(.+?)</span>\n                        <span class=".+?t">(.+?)</span>\n').findall(link)
        for url,name,year in match:
                match=re.compile('<span class="updated">Updated!</span>').findall(name)
                if (len(match)>0):
                        name=name.replace(' <span class="updated">Updated!</span>','')
                        name= name+'  [COLOR red]Recently Updated[/COLOR]'
                addInfo(name,url,'',7,'','','','','','')
        xbmcplugin.setContent(int(sys.argv[1]), 'Movies')
        VIEWS()
        
def LISTPop(murl):
        link=OPENURL(murl)
        match=re.compile('<a href="(.+?)" title="(.+?)"><span class="new_rank">.+?</span>').findall(link)
        for url,name in match:
                addInfo(name,url,'',7,'','','','','','')
                
def LISTSeason(murl):
        link=OPENURL(murl)
        match=re.compile('<h4><a href="#(.+?)">(.+?)</a></h4>\n').findall(link)
        for num,name in match:
                addDir(name,murl,8,'')
                
def LISTEpilist(name,murl):
        link=OPENURL(murl)
        match2=re.compile(r'\d+').findall(name)
        for num in match2:
                x=str(num)
        match=re.compile('class="link-name" href="(.+?)/season/'+x+'/(.+?)">(.+?)</a></td>\n').findall(link)
        for url,url2,name in match:
                url=url+'/season/'+x+'/'+url2
                addDir(name,url,3,'')
        
        
def SEARCH():
        keyb = xbmc.Keyboard('', 'Search For Shows or Episodes')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText()
                encode=urllib.quote(search)
                surl='http://watch-freeseries.mu/index.php?action=episodes_ajaxQuickSearchSuggest&limit=10&keywords='+encode
                req = urllib2.Request(surl)
                req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
                response = urllib2.urlopen(req)
                link=response.read()
                response.close()
                match=re.compile('{"id":".+?","label":".+?","value":"(.+?)","modrwName":"(.+?)"}').findall(link)
                for name,url in match:
                        url=url.replace('\/','/')
                        match=re.compile('season').findall(url)
                        if (len(match)>0):
                                addDir(name,url,3,'')
                        else:
                                addDir(name,url,7,'')

        
def OPENURL(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        return link

def GETLINK(url):
        link=OPENURL(url)
        match=re.compile('<br>\n        <a href="(.+?)" title="" class=".+?"').findall(link)
        for url in match:
                return url
   

def VIDEOLINKS(name,url):
        sources = []
        link=OPENURL(url)
        xbmc.executebuiltin("XBMC.Notification(Please Wait!,This site contains several hosts,3000)")
        match=re.compile('<td width=".+?"><p><a href="(.+?)" target="_blank">putlocker.com</a></p></td>').findall(link)
        for url in match:
                url=GETLINK(url)
                host='Putlocker'
                hosted_media = urlresolver.HostedMediaFile(url=url, title=host)
                sources.append(hosted_media)
        match=re.compile('<td width=".+?"><p><a href="(.+?)" target="_blank">sockshare.com</a></p></td>').findall(link)
        for url in match:
                url=GETLINK(url)
                host='Sockshare'
                hosted_media = urlresolver.HostedMediaFile(url=url, title=host)
                sources.append(hosted_media)
        match=re.compile('<td width=".+?"><p><a href="(.+?)" target="_blank">flashx.tv</a></p></td>').findall(link)
        for url in match:
                url=GETLINK(url)
                host='Flashx'
                hosted_media = urlresolver.HostedMediaFile(url=url, title=host)
                sources.append(hosted_media)
        match=re.compile('<td width=".+?"><p><a href="(.+?)" target="_blank">180upload.com</a></p></td>').findall(link)
        for url in match:
                url=GETLINK(url)
                host='180upload'
                hosted_media = urlresolver.HostedMediaFile(url=url, title=host)
                sources.append(hosted_media)
        match=re.compile('<td width=".+?"><p><a href="(.+?)" target="_blank">nowvideo.eu</a></p></td>').findall(link)
        for url in match:
                url=GETLINK(url)
                host='Nowvideo'
                hosted_media = urlresolver.HostedMediaFile(url=url, title=host)
                sources.append(hosted_media)
        match=re.compile('<td width=".+?"><p><a href="(.+?)" target="_blank">filenuke.com</a></p></td>').findall(link)
        for url in match:
                url=GETLINK(url)
                host='Filenuke'
                hosted_media = urlresolver.HostedMediaFile(url=url, title=host)
                sources.append(hosted_media)
        match=re.compile('<td width=".+?"><p><a href="(.+?)" target="_blank">videoweed.es</a></p></td>').findall(link)
        for url in match:
                url=GETLINK(url)
                host='Videoweed'
                hosted_media = urlresolver.HostedMediaFile(url=url, title=host)
                sources.append(hosted_media)
        match=re.compile('<td width=".+?"><p><a href="(.+?)" target="_blank">novamov.com</a></p></td>').findall(link)
        for url in match:
                url=GETLINK(url)
                host='Novamov'
                hosted_media = urlresolver.HostedMediaFile(url=url, title=host)
                sources.append(hosted_media)
        """match=re.compile('<td width=".+?"><p><a href="(.+?)" target="_blank">vidbux.com</a></p></td>').findall(link)
        for url in match:
                url=GETLINK(url)
                host='Vidbux'
                hosted_media = urlresolver.HostedMediaFile(url=url, title=host)
                sources.append(hosted_media)
        match=re.compile('<td width=".+?"><p><a href="(.+?)" target="_blank">vidxden.com</a></p></td>').findall(link)
        for url in match:
                url=GETLINK(url)
                host= 'Vidxden'
                hosted_media = urlresolver.HostedMediaFile(url=url, title=host)
                sources.append(hosted_media)"""
                
        if (len(sources)==0):
                xbmc.executebuiltin("XBMC.Notification(Sorry!,Show doesn't have playable links,5000)")
      
        else:
                source = urlresolver.choose_source(sources)
                if source:
                        stream_url = source.resolve()
                        if source.resolve()==False:
                                xbmc.executebuiltin("XBMC.Notification(Sorry!,Link Cannot Be Resolved,5000)")
                                return
                else:
                      stream_url = False
                      return
                listitem = xbmcgui.ListItem(name, iconImage="DefaultVideo.png")
                listitem.setInfo('video', {'Title': name, 'Year': ''} )       
                xbmc.Player().play(stream_url, listitem)
                addDir('','','','')
                        

def VIEWS():
        if selfAddon.getSetting("auto-view") == "true":
                if selfAddon.getSetting("choose-skin") == "true":
                        if selfAddon.getSetting("con-view") == "0":
                                xbmc.executebuiltin("Container.SetViewMode(50)")
                        elif selfAddon.getSetting("con-view") == "1":
                                xbmc.executebuiltin("Container.SetViewMode(51)")
                        elif selfAddon.getSetting("con-view") == "2":
                                xbmc.executebuiltin("Container.SetViewMode(500)")
                        elif selfAddon.getSetting("con-view") == "3":
                                xbmc.executebuiltin("Container.SetViewMode(501)")
                        elif selfAddon.getSetting("con-view") == "4":
                                xbmc.executebuiltin("Container.SetViewMode(508)")
                        elif selfAddon.getSetting("con-view") == "5":
                                xbmc.executebuiltin("Container.SetViewMode(504)")
                        elif selfAddon.getSetting("con-view") == "6":
                                xbmc.executebuiltin("Container.SetViewMode(503)")
                        elif selfAddon.getSetting("con-view") == "7":
                                xbmc.executebuiltin("Container.SetViewMode(515)")
                        return
                elif selfAddon.getSetting("choose-skin") == "false":
                        if selfAddon.getSetting("xpr-view") == "0":
                                xbmc.executebuiltin("Container.SetViewMode(50)")
                        elif selfAddon.getSetting("xpr-view") == "1":
                                xbmc.executebuiltin("Container.SetViewMode(52)")
                        elif selfAddon.getSetting("xpr-view") == "2":
                                xbmc.executebuiltin("Container.SetViewMode(501)")
                        elif selfAddon.getSetting("xpr-view") == "3":
                                xbmc.executebuiltin("Container.SetViewMode(55)")
                        elif selfAddon.getSetting("xpr-view") == "4":
                                xbmc.executebuiltin("Container.SetViewMode(54)")
                        elif selfAddon.getSetting("xpr-view") == "5":
                                xbmc.executebuiltin("Container.SetViewMode(60)")
                        elif selfAddon.getSetting("xpr-view") == "6":
                                xbmc.executebuiltin("Container.SetViewMode(53)")
                        return
        else:
                return

def VIEWSB():
        if selfAddon.getSetting("auto-view") == "true":
                        if selfAddon.getSetting("home-view") == "0":
                                xbmc.executebuiltin("Container.SetViewMode(50)")
                        elif selfAddon.getSetting("home-view") == "1":
                                xbmc.executebuiltin("Container.SetViewMode(500)")

                        return
        
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param




def addLink(name,url,iconimage):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
        return ok


def addDir(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

def addInfo(name,url,iconimage,mode,plot,rate,mpaas,gen,yr,fan):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": plot, "Rating": rate,"mpaa": mpaas, "Genre": gen,"Year": yr } )
        liz.setProperty('fanart_image', fan)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
        
              
params=get_params()
url=None
name=None
mode=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass

print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)

if mode==None or url==None or len(url)<1:
        print ""
        MAIN()
       
elif mode==1:
        print ""+url
        LISTEpi(url)

elif mode==6:
        print ""+url
        LISTShows(url)

elif mode==7:
        print ""+url
        LISTSeason(url)

elif mode==8:
        print ""+url
        LISTEpilist(name,url)

elif mode==11:
        print ""+url
        LISTPop(url)

elif mode==2:
        print ""+url
        GENRE(url)

elif mode==4:
        print ""+url
        SEARCH()

elif mode==3:
        print ""+url
        VIDEOLINKS(name,url)

elif mode==5:
        print ""+url
        YEAR()
        
        
elif mode==10:
        print ""+url
        AtoZ()




xbmcplugin.endOfDirectory(int(sys.argv[1]))
