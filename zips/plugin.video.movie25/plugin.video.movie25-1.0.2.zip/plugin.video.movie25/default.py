import urllib,urllib2,re
import xbmc, xbmcgui, xbmcaddon, xbmcplugin
import urlresolver

#Movie25.com - by Mash2k3 2012.

Mainurl ='http://www.movie25.com/movies/'
addon_id = 'plugin.video.movie25'
selfAddon = xbmcaddon.Addon(id=addon_id)
def MAIN():
        addDir('Search','http://www.movie25.com/',4,'')
        addDir('New Releases','http://www.movie25.com/movies/new-releases/',1,'')
        addDir( 'Latest Added','http://www.movie25.com/movies/latest-added/',1,'')
        addDir('Featured Movies','http://www.movie25.com/movies/featured-movies/',1,'')
        addDir( 'Most Viewed','http://www.movie25.com/movies/most-viewed/',1,'')
        addDir('Most Voted','http://www.movie25.com/movies/most-voted/',1,'')
        addDir( 'Genre','http://www.movie25.com/',2,'')
        
def GENRE(url):
        addDir('Action','http://www.movie25.com/movies/action/',1,'')
        addDir('Adventure','http://www.movie25.com/movies/adventure/',1,'')
        addDir('Animation','http://www.movie25.com/movies/animation/',1,'')
        addDir('Biography','http://www.movie25.com/movies/biography/',1,'')
        addDir('Comedy','http://www.movie25.com/movies/comedy/',1,'')
        addDir('Crime','http://www.movie25.com/movies/crime/',1,'')
        addDir('Documentary','http://www.movie25.com/movies/documentary/',1,'')
        addDir('Drama','http://www.movie25.com/movies/drama/',1,'')
        addDir('Family','http://www.movie25.com/movies/family/',1,'')
        addDir('Fantasy','http://www.movie25.com/movies/fantasy/',1,'')
        addDir('History','http://www.movie25.com/movies/history/',1,'')
        addDir('Horror','http://www.movie25.com/movies/horror/',1,'') 
        addDir('Music','http://www.movie25.com/movies/music/',1,'')
        addDir('Musical','http://www.movie25.com/movies/musical/',1,'')
        addDir('Mystery','http://www.movie25.com/movies/mystery/',1,'')
        addDir('Romance','http://www.movie25.com/movies/romance/',1,'')
        addDir('Sci-Fi','http://www.movie25.com/movies/sci-fi/',1,'')
        addDir('Short','http://www.movie25.com/movies/short/',1,'')
        addDir('Sport','http://www.movie25.com/movies/sport/',1,'')
        addDir('Thriller','http://www.movie25.com/movies/thriller/',1,'')
        addDir('War','http://www.movie25.com/movies/war/',1,'')
        addDir('Western','http://www.movie25.com/movies/western/',1,'')
 
        
def LISTMOVIES(murl):
        link=OPENURL(murl)
        match=re.compile('<div class="movie_pic"><a href="(.+?)" ><img src="(.+?)" width=".+?" height=".+?" /></a></div>\n  <div class="movie_about">\n    <div class="movie_about_text">\n      <h1><a href=".+?" >(.+?)</a></h1>\n      <div class="c">Genre:      <a href=".+?/" title=\'.+?\'>(.+?)</a>').findall(link)
        # got help from j0anita above
        dialogWait = xbmcgui.DialogProgress()
        dialogWait.create('Movie25', 'Will Load Faster If Metadata is Disabled')
        for url,thumb,mname,genre in match:
                namelen=len(mname)
                nam= namelen- 5
                year = mname[nam:namelen-1]
                name= mname[0:namelen-6]
                name=name.replace('-','')
                if selfAddon.getSetting("meta-view") == "true":
                        user_agent = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:10.0a1) Gecko/20111029 Firefox/10.0a1'
                        txheaders= {'Accept': 'application/json','User-Agent':user_agent}
                        req = urllib2.Request('http://api.themoviedb.org/2.1/Movie.browse/en-US/xml/6ee3768ba155b41252384a1148398b34?&order=asc&year=%s&query=%s&per_page=1'%(year,urllib.quote_plus(name)),None,txheaders)
                        response=urllib2.urlopen(req).read()
                try: desc=re.compile('<overview>(.+?)</overview>').findall(response)[0]
                except: desc='No Plot Found'
                try: rating=float(re.compile('<rating>(.+?)</rating>').findall(response)[0])
                except: rating=float(0.0)
                try: cert="%s"%re.compile('<certification>(.+?)</certification>').findall(response)[0]
                except: cert=''
                try:fanart=re.compile('<image type="backdrop" url="(.+?)" size="poster" width=".+?" height=".+?" id=".+?"/>').findall(response)[0]
                except: fanart=''
                if selfAddon.getSetting("poster-view") == "true":
                        try:poster=re.compile('<image type="poster" url="(.+?)" size="cover" width=".+?" height=".+?" id=".+?"/>').findall(response)[0]
                        except:poster=thumb
                else:
                        poster=thumb
                
                
                addInfo(name+'('+year+')',url,3,poster,desc,rating,cert,genre,year,fanart)
        dialogWait.close()
        del dialogWait
                
                #addDir(name,url,3,thumb)
        paginate=re.compile('http://www.movie25.com/movies/.+?/index-(.+?).html').findall(murl)
       
        if (len(paginate) == 0):
                purl = murl + 'index-2.html'
                addDir('[COLOR blue]Page 2[/COLOR]',purl,1,'')
        else:
                paginate=re.compile('http://www.movie25.com/movies/(.+?)/index-(.+?).html').findall(murl)
                for section, page in paginate:
                        pg= int(page) +1
                        xurl = Mainurl + str(section) + '/' + 'index-'+ str (pg) + '.html'
                addDir('[COLOR red]Home[/COLOR]','',0,'')
                addDir('[COLOR blue]Page '+ str(pg)+'[/COLOR]',xurl,1,'')
        xbmcplugin.setContent(int(sys.argv[1]), 'Movies')
        VIEWS()

                
def SEARCH():
        keyb = xbmc.Keyboard('', 'Pesquisar filmes no wareztuga.tv')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText()
                encode=urllib.quote(search)
                surl='http://www.movie25.com/search.php?key='+encode+'&submit='
                req = urllib2.Request(surl)
                req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
                response = urllib2.urlopen(req)
                link=response.read()
                response.close()
                match=re.compile('<div class="movie_pic"><a href="(.+?)" target="_blank">\n                            <img src="(.+?)" width=".+?" height=".+?" />\n                            </a></div>\n            <div class="movie_about">\n              <div class="movie_about_text">\n                <h1><a href=".+?" target="_blank">\n                  (.+?)                </a></h1>\n                <div class="c">Genre:\n                  <a href=".+?" target=\'.+?\'>(.+?)</a>').findall(link)
                dialogWait = xbmcgui.DialogProgress()
                dialogWait.create('Movie25', 'Will Load Faster If Metadata is Disabled')
                for url,thumb,mname,genre in match:
                        namelen=len(mname)
                        nam= namelen- 7
                        year = mname[nam:namelen-3]
                        name= mname[0:namelen-8]
                        name=name.replace('-','')
                        if selfAddon.getSetting("meta-view") == "true":
                                user_agent = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:10.0a1) Gecko/20111029 Firefox/10.0a1'
                                txheaders= {'Accept': 'application/json','User-Agent':user_agent}
                                req2 = urllib2.Request('http://api.themoviedb.org/2.1/Movie.browse/en-US/xml/6ee3768ba155b41252384a1148398b34?&order=asc&year=%s&query=%s&per_page=1'%(year,urllib.quote_plus(name)),None,txheaders)
                                response2=urllib2.urlopen(req2).read()
                        try: desc=re.compile('<overview>(.+?)</overview>').findall(response2)[0]
                        except: desc='No Plot Found'
                        try: rating=float(re.compile('<rating>(.+?)</rating>').findall(response2)[0])
                        except: rating=float(0.0)
                        try: cert="%s"%re.compile('<certification>(.+?)</certification>').findall(response2)[0]
                        except: cert=''
                        try:fanart=re.compile('<image type="backdrop" url="(.+?)" size="poster" width=".+?" height=".+?" id=".+?"/>').findall(response2)[0]
                        except: fanart=''
                        if selfAddon.getSetting("poster-view") == "true":
                                try:poster=re.compile('<image type="poster" url="(.+?)" size="cover" width=".+?" height=".+?" id=".+?"/>').findall(response)[0]
                                except:poster=thumb
                        else:
                                poster=thumb
                        furl= 'http://movie25.com/'+url
                        addInfo(name+'('+year+')',furl,3,poster,desc,rating,cert,genre,year,fanart)
                dialogWait.close()
                del dialogWait
                addDir('[COLOR blue]Page 2[/COLOR]','http://www.movie25.com/search.php?page=2&key='+encode,9,'')

def NEXTPAGE(murl):
        link=OPENURL(murl)
        match=re.compile('<div class="movie_pic"><a href="(.+?)" target="_blank">\n                            <img src="(.+?)" width=".+?" height=".+?" />\n                            </a></div>\n            <div class="movie_about">\n              <div class="movie_about_text">\n                <h1><a href=".+?" target="_blank">\n                  (.+?)                </a></h1>\n                <div class="c">Genre:\n                  <a href=".+?" target=\'.+?\'>(.+?)</a>').findall(link)
        dialogWait = xbmcgui.DialogProgress()
        dialogWait.create('Movie25', 'Will Load Faster If Metadata is Disabled')
        #match=re.compile('<div class="movie_pic"><a href="(.+?)" target="_blank">\n                            <img src="(.+?)" width=".+?" height=".+?" />\n                            </a></div>\n            <div class="movie_about">\n              <div class="movie_about_text">\n                <h1><a href=".+?" target="_blank">\n                  (.+?)                </a></h1>\n').findall(link)
        for url,thumb,mname,genre in match:
                namelen=len(mname)
                nam= namelen- 7
                year = mname[nam:namelen-3]
                name= mname[0:namelen-8]
                name=name.replace('-','')
                if selfAddon.getSetting("meta-view") == "true":
                         user_agent = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:10.0a1) Gecko/20111029 Firefox/10.0a1'
                         txheaders= {'Accept': 'application/json','User-Agent':user_agent}
                         req2 = urllib2.Request('http://api.themoviedb.org/2.1/Movie.browse/en-US/xml/6ee3768ba155b41252384a1148398b34?&order=asc&year=%s&query=%s&per_page=1'%(year,urllib.quote_plus(name)),None,txheaders)
                         response2=urllib2.urlopen(req2).read()
                try: desc=re.compile('<overview>(.+?)</overview>').findall(response2)[0]
                except: desc='No Plot Found'
                try: rating=float(re.compile('<rating>(.+?)</rating>').findall(response2)[0])
                except: rating=float(0.0)
                try: cert="%s"%re.compile('<certification>(.+?)</certification>').findall(response2)[0]
                except: cert=''
                try:fanart=re.compile('<image type="backdrop" url="(.+?)" size="poster" width=".+?" height=".+?" id=".+?"/>').findall(response2)[0]
                except: fanart=''
                if selfAddon.getSetting("poster-view") == "true":
                        try:poster=re.compile('<image type="poster" url="(.+?)" size="cover" width=".+?" height=".+?" id=".+?"/>').findall(response)[0]
                        except:poster=thumb
                else:
                        poster=thumb
                furl= 'http://movie25.com/'+url
                addInfo(name+'('+year+')',furl,3,poster,desc,rating,cert,genre,year,fanart)
                
        dialogWait.close()
        del dialogWait
        durl = murl + '/'
        paginate=re.compile('http://www.movie25.com/search.php.+?page=(.+?)&key=(.+?)/').findall(durl)
        for page, search in paginate:
                pgs = int(page)+1
                jurl='http://www.movie25.com/search.php?page='+str(pgs)+'&key='+str(search)
        addDir('[COLOR red]Home[/COLOR]','',0,'')
        addDir('[COLOR blue]Page '+str(pgs)+'[/COLOR]',jurl,9,'')
        
        
def OPENURL(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        return link


def VIDEOLINKS(name,url):
        link=OPENURL(url)
        putlocker=re.compile('<li class=link_name>putlocker</li>.+?javascript:window.open.+?url=(.+?)\'').findall(link)
        # got help from j0anita pulling the video file from link
        if len(putlocker) > 0:
                addInfo(name+"[COLOR blue] : Putlocker[/COLOR]",url,11,'','','','','','','')
        oeupload=re.compile('<li class=link_name>180upload</li>.+?javascript:window.open.+?url=(.+?)\'').findall(link)
        if len(oeupload) > 0:
                addInfo(name+"[COLOR blue] : 180upload[/COLOR]",url,12,'','','','','','','')
        filenuke=re.compile('<li class=link_name>filenuke</li>.+?javascript:window.open.+?url=(.+?)\'').findall(link)
        if len(filenuke) > 0:
                addInfo(name+"[COLOR blue] : Filenuke[/COLOR]",url,13,'','','','','','','')
        flashx=re.compile('<li class=link_name>flashx</li>.+?javascript:window.open.+?url=(.+?)\'').findall(link)
        if len(flashx) > 0:
                addInfo(name+"[COLOR blue] : Flashx[/COLOR]",url,15,'','','','','','','')
        vidbux=re.compile('<li class=link_name>vidbux</li>.+?javascript:window.open.+?url=(.+?)\'').findall(link)
        if len(vidbux) > 0:
                addInfo(name+"[COLOR blue] : Vidbux[/COLOR]",url,14,'','','','','','','')
                
        
        
        

def PUTLINKS(name,url):
        link=OPENURL(url)
        putlocker=re.compile('<li class=link_name>putlocker</li>.+?javascript:window.open.+?url=(.+?)\'').findall(link)
        for url in putlocker:
                #addDir("putlocker",url,5,'')
                addInfo(name,url,5,'','','','','','','')
def OELINKS(name,url):
        link=OPENURL(url)
        oeupload=re.compile('<li class=link_name>180upload</li>.+?javascript:window.open.+?url=(.+?)\'').findall(link)
        for url in oeupload:
                addInfo(name,url,5,'','','','','','','')
def FNLINKS(name,url):
        link=OPENURL(url)
        filenuke=re.compile('<li class=link_name>filenuke</li>.+?javascript:window.open.+?url=(.+?)\'').findall(link)
        for url in filenuke:
                addInfo(name,url,5,'','','','','','','')
def FLALINKS(name,url):
        link=OPENURL(url)
        flashx=re.compile('<li class=link_name>flashx</li>.+?javascript:window.open.+?url=(.+?)\'').findall(link)
        for url in flashx:
                addInfo(name,url,5,'','','','','','','')
def VIDLINKS(name,url):
        link=OPENURL(url)
        vidbux=re.compile('<li class=link_name>vidbux</li>.+?javascript:window.open.+?url=(.+?)\'').findall(link)
        for url in vidbux:
                addInfo(name,url,5,'','','','','','','')

                
def PLAY(name,url):
        playlist = xbmc.PlayList(1)
        playlist.clear()
        listitem = xbmcgui.ListItem(name, iconImage="DefaultVideo.png")
        #print name
        listitem.setInfo("Video", {"Title":name})
        listitem.setProperty('mimetype', 'video/x-msvideo')
        listitem.setProperty('IsPlayable', 'true')
        media = urlresolver.HostedMediaFile(url)
        source = media
        dialog = xbmcgui.Dialog()
        if source:
                stream_url = source.resolve()
                if source.resolve()==False:
                        ok=dialog.ok('Movie25', 'Link is Dead')
                        return
        else:
              stream_url = False  
                
        #dialogWait.close()
        #del dialogWait
        playlist.add(stream_url,listitem)
        xbmcPlayer = xbmc.Player(xbmc.PLAYER_CORE_AUTO)
        xbmcPlayer.play(playlist)
        #xbmc.Player().play(stream_url,listitem)
        addDir('','','','')# got help from j0anita

def VIEWS():
        if selfAddon.getSetting("auto-view") == "true":
                if selfAddon.getSetting("choose-skin") == "0":
                        if selfAddon.getSetting("con-view") == "0":
                                xbmc.executebuiltin("Container.SetViewMode(50)")
                        elif selfAddon.getSetting("con-view") == "1":
                                xbmc.executebuiltin("Container.SetViewMode(51)")
                        elif selfAddon.getSetting("con-view") == "2":
                                xbmc.executebuiltin("Container.SetViewMode(500)")
                        elif selfAddon.getSetting("con-view") == "3":
                                xbmc.executebuiltin("Container.SetViewMode(501)")
                        elif selfAddon.getSetting("con-view") == "4":
                                xbmc.executebuiltin("Container.SetViewMode(508)")
                        elif selfAddon.getSetting("con-view") == "5":
                                xbmc.executebuiltin("Container.SetViewMode(504)")
                        elif selfAddon.getSetting("con-view") == "6":
                                xbmc.executebuiltin("Container.SetViewMode(503)")
                        elif selfAddon.getSetting("con-view") == "7":
                                xbmc.executebuiltin("Container.SetViewMode(515)")
                        return
                elif selfAddon.getSetting("choose-skin") == "1":
                        if selfAddon.getSetting("xpr-view") == "0":
                                xbmc.executebuiltin("Container.SetViewMode(50)")
                        elif selfAddon.getSetting("xpr-view") == "1":
                                xbmc.executebuiltin("Container.SetViewMode(52)")
                        elif selfAddon.getSetting("xpr-view") == "2":
                                xbmc.executebuiltin("Container.SetViewMode(501)")
                        elif selfAddon.getSetting("xpr-view") == "3":
                                xbmc.executebuiltin("Container.SetViewMode(55)")
                        elif selfAddon.getSetting("xpr-view") == "4":
                                xbmc.executebuiltin("Container.SetViewMode(54)")
                        elif selfAddon.getSetting("xpr-view") == "5":
                                xbmc.executebuiltin("Container.SetViewMode(60)")
                        elif selfAddon.getSetting("xpr-view") == "6":
                                xbmc.executebuiltin("Container.SetViewMode(53)")
                        return
        else:
                return

        
        
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param




def addLink(name,url,iconimage):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
        return ok


def addDir(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

def addInfo(name,url,mode,iconimage,plot,rate,mpaas,gen,yr,fan):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": plot, "Rating": rate,"mpaa": mpaas, "Genre": gen,"Year": yr } )
        liz.setProperty('fanart_image', fan)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
        
              
params=get_params()
url=None
name=None
mode=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass

print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)

if mode==None or url==None or len(url)<1:
        print ""
        MAIN()
       
elif mode==1:
        print ""+url
        LISTMOVIES(url)
        
elif mode==2:
        print ""+url
        GENRE(url)

elif mode==4:
        print ""+url
        SEARCH()

elif mode==3:
        print ""+url
        VIDEOLINKS(name,url)

elif mode==5:
        print ""+url
        PLAY(name,url)

elif mode==9:
        print ""+url
        NEXTPAGE(url)

elif mode==11:
        print ""+url
        PUTLINKS(name,url)

elif mode==12:
        print ""+url
        OELINKS(name,url)

elif mode==13:
        print ""+url
        FNLINKS(name,url)

elif mode==14:
        print ""+url
        VIDLINKS(name,url)

elif mode==15:
        print ""+url
        FLALINKS(name,url)


xbmcplugin.endOfDirectory(int(sys.argv[1]))
